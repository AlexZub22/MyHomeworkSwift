import Cocoa
import Darwin
import Foundation
/*1. После соревнований по боксу сумму ХХХХХ р. распределили между спортсменами, занявшими 1, 2, 3 отношении 7:3:1. Найдите вознаграждение, которую получил каждый призёр.
  */

  let prizeFund: Double = 10000
  let firstPlace = (prizeFund/11)*7
  let secondPlace = (prizeFund/11)*3
  let thirdPlace = (prizeFund/11)*1
  firstPlace + secondPlace + thirdPlace

  /*2. Пилот формулы 1 завершил гонку за три часа, проехав 90 кругов. Его средняя скорость составила 180 км/ч. Какова длина одного круга? Ответ требуется дать в километрах.
   */

  let pilotSpeed = 180
  let pilotTime = 3
  let countOfCircles = 90
  let pilotDist = pilotTime * pilotSpeed
  let oneCircleDist = pilotDist / countOfCircles
  print("Длина одного круга составляет \(oneCircleDist) километров")

  /*3.Пирожок в столовой стоит a рублей и b копеек. Определите, сколько рублей и копеек нужно заплатить за n пирожков. Ответ требуется вывести в виде кортежа (rub: Int, kop: Int)
   */

  let pieRubleprice = 10
  let pieKopPrice = 50
  let pieNumber = 10

  let price = (pieNumber*(pieRubleprice*100 + pieKopPrice))/100
  let tuple = (rub: (pieNumber*(pieRubleprice*100))/100 + (pieNumber*pieKopPrice)/100, kop: pieNumber*(pieKopPrice)%100)

  /*4.Даны значения двух моментов времени, принадлежащих одним и тем же суткам: часы, минуты и секунды для каждого из моментов времени. Известно, что второй момент времени наступил не раньше первого. Определите, сколько часов, минут и секунд прошло между двумя моментами времени.
   */
  let moment1 = (hours: 10, minutes: 34, seconds: 55)
  let moment2 = (hours: 14, minutes: 15, seconds: 33)
  let differenceHours = moment2.0 - moment1.0
  let differenceMinutes = moment2.1 - moment1.1
  let differenceSeconds = moment2.2 - moment1.2
  let differenceOfMoments = (hours: (differenceHours > 0 ? differenceHours : -differenceHours) , minutes: (differenceMinutes > 0 ? differenceMinutes : -differenceMinutes), seconds: (differenceSeconds > 0 ? differenceSeconds : -differenceSeconds))

  /* 5.Дана переменная num, которая может быть либо отрицательной, либо положительной. Запишите в переменную result строку "Positive", если переменная num больше или равна нулю, и число "Negative", если переменная num меньше нуля.
   */

  var num = -5
  var result: String

  let operation: () = num > 0 ? (result = "Positive") : (result = "Negative")
  print(result)

