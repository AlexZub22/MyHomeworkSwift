import Cocoa
import Foundation
import Darwin

//1. Создайте структуру с именем student, содержащую поля: фамилия и инициалы, номер группы, успеваемость (массив из пяти элементов). Создать массив из десяти элементов такого типа, упорядочить записи по возрастанию среднего балла. Добавить возможность вывода фамилий и номеров групп студентов, имеющих оценки, равные только 4 или 5.
class Student {
    var surname: String
    var initials: String
    var groupNumber: Int
    var perf: [Double]

    
    init(surname: String, initials: String, groupNumber: Int, perf: [Double]) {
        self.surname = surname
        self.initials = initials
        self.groupNumber = groupNumber
        self.perf = perf
    }
    func middleMark() -> Double {
        var middleMark: Double = 0
        for i in perf {
            middleMark += i
        }
        return middleMark / Double(perf.count)
    }
    
}

let popov = Student(surname: "Попов", initials: "А.А", groupNumber: 2, perf: [5, 4, 5, 3, 5])
let petrov = Student(surname: "Петров", initials: "В.С", groupNumber: 1, perf: [5, 4, 5, 4, 5])
let sergeeva = Student(surname: "Сергеева", initials: "В.В", groupNumber: 2, perf: [5, 5, 5, 5, 5])
let kuznecov = Student(surname: "Кузнецов", initials: "Д.И", groupNumber: 1, perf: [4, 4, 3, 3, 5])
let mihailova = Student(surname: "Михайлова", initials: "С.А", groupNumber: 1, perf: [5, 4, 4, 5, 4])
let ponteleev = Student(surname: "Понтелеев", initials: "А.Н", groupNumber: 1, perf: [4, 3, 3, 5, 5])
let andreeva = Student(surname: "Андреева", initials: "Е.А", groupNumber: 2, perf: [5, 5, 3, 5, 4])
let fedorova = Student(surname: "Федорова", initials: "О.М", groupNumber: 2, perf: [4, 4, 5, 5, 5])
let stoliarov = Student(surname: "Столяров", initials: "Е.Д", groupNumber: 1, perf: [5, 4, 5, 5, 5])
let goncharov = Student(surname: "Гончаров", initials: "П.А", groupNumber: 2, perf: [5, 4, 3, 3, 5])
    
var students: [Student] = [popov, petrov, sergeeva, kuznecov, mihailova, ponteleev, andreeva, fedorova, stoliarov, goncharov]
kuznecov.middleMark()
var sortStudents = students.sorted(by: {$0.middleMark() < $1.middleMark()})
sortStudents
for student in students {
    let cond = student.perf.contains(1) || student.perf.contains(2) || student.perf.contains(3)
    if cond == false {
        print ("Студент \(student.surname) из группы \(student.groupNumber) имеет оценки 4 и 5")
    }
}
//2. Создать класс Круг с хранимым свойством Радиус. Добавить ему вычисляемые свойства - длина окружности и площадь круга. Добавить метод "Вытянуть в цилиндр", который принимает высоту цилиндра и возвращает объем цилиндра
class Circle {
    var radius: Double
    var circleLenght: Double {
        2 * 3.14 * radius
    }
    var circleSquare: Double {
        3.14 * radius * radius
    }
    init(radius: Double) {
        self.radius = radius
    }
    func cylinder(height: Double) -> Double {
        let volume = 3.14 * radius * 2 * height
        return volume
    }
}
let circle1 = Circle(radius: 5)
circle1.circleSquare
circle1.circleLenght
circle1.cylinder(height: 6)

//3. Требуется проверить, возможно ли из представленных отрезков условной длины сформировать треугольник. Для этого нужно создать класс TriangleChecker, принимающий только положительные числа. С помощью метода isTriangle() возвращаются следующие значения (в зависимости от ситуации): – Ура, можно построить треугольник!; – С отрицательными числами ничего не выйдет!; – Жаль, но из этого треугольник не сделать. Треугольник можно создать, только если сумма любых двух из его сторон больше третьей стороны
class TriangleCheker {
    var side1: Double
    var side2: Double
    var side3: Double
    
    init(side1: Double, side2: Double, side3: Double) {
        self.side1 = side1
        self.side2 = side2
        self.side3 = side3
    }
    func isTriangle() {
        let condition1 = side1 + side2 > side3 || side2 + side3 > side1 || side3 + side1 > side2
        let condition2 = side1 > 0 && side2 > 0 && side3 > 0
        if condition1 && condition2 == true {
            print("Ура, можно построить треугольник!")
        } else if condition2 == false {
            print("С отрицательными числами ничего не выйдет!")
        } else if condition1 == false, condition2 == true {
            print("Жаль, но из этого треугольник не сделать.")
        }
    }
}
let triangle1 = TriangleCheker(side1: 5, side2: 3, side3: 2)
triangle1.isTriangle()

//4. Класс Покупатель: Фамилия, Имя, Отчество, Адрес, Баланс карты, методы - купить товар (принимает стоимость и количество, возвращает результат покупки типа Bool - получилось/не получилось), вывод информации о пользователе в консоль. *Создать массив объектов данного класса. Вывести список покупателей в алфавитном порядке и список покупателей, у которых баланс кредитной карточки находится в заданном диапазоне.
class Buyer {
    let surname: String
    let name: String
    let middleName: String
    var adress: String
    var balance: Int
    init(surname: String, name: String, middleName: String, adress: String, balance: Int) {
        self.surname = surname
        self.name = name
        self.middleName = middleName
        self.adress = adress
        self.balance = balance
    }
    func buy(price: Int, count: Int) -> Bool {
        let cond1 = price * count < balance
        if cond1 == true {
            print("Покупка товара выполнена успешно!")
        } else {
            print("Покупка не совершена! Не хватает средств.")
        }
        return cond1
    }
    func info() {
        print("Покупатель \(surname) \(name) \(middleName). Адрес: \(adress). Баланс карты: \(balance)")
    }
}
let buyer1 = Buyer(surname: "Петров", name: "Александр", middleName: "Сергеевич", adress: "Москва, ул. Строителей, дом 5, квартира 25", balance: 35000)
let buyer2 = Buyer(surname: "Магамедов", name: "Даниял", middleName: "Магомед оглы", adress: "Махачкала, ул. Ахметхана Султана, дом 7, квартира 33 ", balance: 29000)
let buyer3 = Buyer(surname: "Павлюченко", name: "Ольга", middleName: "Владимировна", adress: "Донецк, ул. Московская, дом 40, квартира 70", balance: 40000)
var buyers = [buyer1, buyer2, buyer3]
buyers.sorted(by: {$0.name > $1.name})
var sortBuyers = [Buyer]()
for buyer in buyers {
    if ...30000 ~= buyer.balance {
        sortBuyers.append(buyer)
    }
}
sortBuyers
