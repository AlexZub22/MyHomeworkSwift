import Cocoa
import Foundation
import Darwin

///1. Создать 4 класса (родительский - Животное и 3 потомка), описывающих некоторых хищных животных (один из потомков), всеядных(второй потомок) и травоядных (третий потомок). Описать в базовом классе свойства количество и тип пищи, необходимого для пропитания животного в зоопарке. Создать массив животных, добавить туда нескольких животных разных типов
///a) Упорядочить всю последовательность животных по убыванию количества пищи. Вывести в консоль имя, тип и количество потребляемой пищи для всех элементов списка.
///b) Вывести первые 5 имен животных из полученного в пункте а) списка.
///c) Вывести последние 3 количества пищи животных из полученного в пункте а) списка.
class Animal {
    var foodAmount: Int
    var foodType: String
    init(amount: Int, foodType: String) {
        self.foodAmount = amount
        self.foodType = foodType
    }
}
class Predatory: Animal {
    var title: String
    init(title: String, amount: Int) {
        self.title = title
        super.init(amount: amount, foodType: "мясо")
    }
}

class Omnivorous: Animal {
    var title: String
    init(title: String, amount: Int) {
        self.title = title
        super.init(amount: amount, foodType: "мясо и растения")
    }
}

class Herbivorous: Animal {
    var title: String
    init(title: String, amount: Int) {
        self.title = title
        super.init(amount: amount, foodType: "растения")
    }
}

let hippopotamus = Omnivorous(title: "Бегемот", amount: 100)
let tiger = Predatory(title: "Тигр", amount: 40)
let giraffe = Herbivorous(title: "Жираф", amount: 25)
let elephant = Herbivorous(title: "Слон", amount: 70)
let monkey = Omnivorous(title: "Обезьяна", amount: 5)
let woolf = Predatory(title: "Волк", amount: 10)
var animals:[Animal] = [hippopotamus, tiger, giraffe, elephant, monkey, woolf]
animals.sort(by: {$0.foodAmount > $1.foodAmount})
animals
animals.count
for i in 1...3 {
  print("\(animals[animals.count - i].foodAmount)")
}
/*for (key,animal) in animals.enumerated() {
    if let omni = animal as? Omnivorous {
        print("\(omni.title)")
    } else if let pred = animal as? Predatory {
        print("\(pred.title)")
    } else if let herb = animal as? Herbivorous {
        print("\(herb.title)")
    }
    while key == 4 {
    }
}*/
///2. Описать класс «домашняя библиотека». Предусмотреть возможность поиска книги по каким-либо признакам (например, по названию, автору и по году издания), добавления книг в библиотеку, удаления книг из нее, сортировки книг по разным свойствам.
class HomeLib {
}
class Book: HomeLib {
    let title: String
    let genre: String
    let pages: Int
    let author: String
    let yearOfPub: Int
    init(genre: String, pages: Int, author: String, yearOfPub: Int, title: String) {
        self.yearOfPub = yearOfPub
        self.author = author
        self.genre = genre
        self.pages = pages
        self.title = title
    }
}
let littlePrince = Book(genre: "Сказка", pages: 80, author: "Антуан де Сент-Экзюпери", yearOfPub: 1942, title: "Маленький принц")
let lesMiserables = Book(genre: "Роман", pages: 600, author: "Виктор Гюго", yearOfPub: 1862, title: "Отверженные")
let algernon = Book(genre: "Научная фантастика", pages: 300, author: "Дэниел Киз", yearOfPub: 1959, title: "Цветы для Элджерона")
let morgenrote = Book(genre: "Философия", pages: 600, author: "Фридрих Ницше", yearOfPub: 1881, title: "Утренняя Заря")
let harryPotter = Book(genre: "Сказка", pages: 500, author: "Джоан Роулинг", yearOfPub: 1997, title: "Гарри Поттер и фолосовский камень")
var library: [HomeLib] = [littlePrince, lesMiserables, algernon, morgenrote]
for element in library {
    if let book = element as? Book {
        if book.title == "Маленький принц" {
            print("Книгу под названием Маленький принц написал \(book.author)")
        } else if book.pages > 500 {
            print("В книге \(book.title) больше 500 страниц")
        } else if harryPotter.genre == "Сказка" {
            library.append(harryPotter)
            print("В библиотеку добавлена книга \(harryPotter.title)")
    }
}
}
///3. Создать класс для представления времени. Предусмотреть возможности установки времени и изменения его отдельных полей (час, минута, секунда) с проверкой допустимости вводимых значений. В случае недопустимых значений свойств экземпляр не создаётся. Создать методы изменения времени на заданное количество часов, минут и секунд.
class Time {
    var hours: Int
    var minutes: Int
    var seconds: Int
    init?(hours: Int, minutes: Int, seconds: Int) {
        self.hours = hours
        self.minutes = minutes
        self.seconds = seconds
        guard hours > 0 && hours < 24 else {
            print("Количество часов задано неверно")
            return nil
        }
        guard minutes > 0 && minutes < 60 else {
            print("Количество минут задано неверно")
            return nil
        }
        guard seconds > 0 && seconds < 60 else {
            print("Количество секунд задано неверно")
            return nil
            }
    }
    func showTime() {
        print("\(hours) часов \(minutes) минут \(seconds) секунд")
    }
    func plusTime(plusHour: Int, plusMinute: Int, plusSeconds: Int) {
        var newHour = 0
        var newMinute = 0
        var newSecond = 0
        let cond1 = hours + plusHour >= 24
        let cond2 = minutes + plusMinute >= 60
        let cond3 = seconds + plusSeconds >= 60
        if cond1 == true {
            newHour = (hours + plusHour) % 24
        } else {
            newHour = hours + plusHour
        }
        if cond2 == true {
            newMinute = (minutes + plusMinute) % 60
        } else {
            newMinute = minutes + plusMinute
        }
        if cond3 == true {
            newSecond = (seconds + plusSeconds) % 60
        } else {
            newSecond = seconds + plusSeconds
        }
        
        print("Время после изменения составляет \(newHour) часов \(newMinute) минут \(newSecond) секунд")
        }
    func minusTime(minusHour: Int, minusMinute: Int, minusSecond: Int) {
        var newHour = 0
        var newMinute = 0
        var newSecond = 0
        let cond1 = sqrt(Double((hours - minusHour) * (hours - minusHour))) >= 24
        let cond2 = sqrt(Double((minutes - minusMinute) * (minutes - minusMinute))) >= 60
        let cond3 = sqrt(Double((seconds - minusSecond) * (seconds - minusSecond))) >= 60
        if cond1 == true {
            newHour = Int(sqrt(Double((hours - minusHour) * (hours - minusHour)))) % 24
        } else {
            newHour = Int(Double(hours - minusHour))
        }
        if cond2 == true {
            newMinute = Int(sqrt(Double((minutes - minusMinute) * (minutes - minusMinute)))) % 60
        } else {
            newMinute = Int(Double(minutes - minusMinute))
        }
        if cond3 == true {
            newSecond = Int(sqrt(Double((seconds - minusSecond) * (seconds - minusSecond)))) % 60
        } else {
            newSecond = Int(Double(seconds - minusSecond))
        }
        
        print("Время после изменения составляет \(newHour) часов \(newMinute) минут \(newSecond) секунд")
    }
}

let time1 = Time(hours: 12, minutes: 50, seconds: 59)
time1?.showTime()
time1?.plusTime(plusHour: 29, plusMinute: 120, plusSeconds: 300)
time1?.minusTime(minusHour: 2000, minusMinute: 4, minusSecond: 50)
