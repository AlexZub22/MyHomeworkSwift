import Cocoa
//1. Имеется структура завод, содержащая свойства Название, год, Работники. Работник - тоже структура следующего вида: фамилия, возраст, специальность, оклад. Создать вычисляемое свойство Фонд зарплаты, в котором учитываются зарплаты всех сотрудников завода, увеличенные на 42% (взносы в ПФР и ФСС). Создать вычисляемое свойство Средняя зарплата. Также требуется произвольно ввести информацию по 2м заводам, посчитать количество слесарей и токарей. Напечатать эти значения. Произвести тестирование работы программы.

struct Plant {
    let title: String
    let year: Int
    var workers: [Worker]
    var salaryFund: Double {
        var fund: Double = 0
        for worker in workers {
            fund += worker.salaryBase * 1.42
        }
        return fund
    }
    
}
struct Worker {
    let surname: String
    var age: Int
    let speciality: String
    var salaryBase: Double
}
let locksmith1 = Worker(surname: "Васильев", age: 45, speciality: "Слесарь", salaryBase: 50000)
let locksmith2 = Worker(surname: "Дорбаидзе", age: 50, speciality: "Слесарь", salaryBase: 55000)
let turner1 = Worker(surname: "Михайлов", age: 40, speciality: "Токарь", salaryBase: 52000)
let turner2 = Worker(surname: "Цой", age: 55, speciality: "Токарь", salaryBase: 69000)
let locksmith3 = Worker(surname: "Магомедов", age: 39, speciality: "Слесарь", salaryBase: 45000)
let locksmith4 = Worker(surname: "Нигматуллин", age: 50, speciality: "Слесарь", salaryBase: 58000)
let locksmith5 = Worker(surname: "Петров", age: 55, speciality: "Слесарь", salaryBase: 70000)
let turner3 = Worker(surname: "Дабаев", age: 45, speciality: "Токарь", salaryBase: 55000)
let turner4 = Worker(surname: "Микоян", age: 50, speciality: "Токарь", salaryBase: 70000)
let uazPlant = Plant(title: "Уральский автомобильный завод", year: 1941, workers: [locksmith1, locksmith2, turner1, turner2])
let kamazPlant = Plant(title: "Камский автомобильный завод", year: 1969, workers: [locksmith3, locksmith4, locksmith5, turner3, turner4])
print("Фонд заработной платы на заводе УАЗ составляет \(uazPlant.salaryFund) рублей.")
print("Фонд заработной платы на заводе КАМАЗ составляет \(kamazPlant.salaryFund) рублей.")
var uazTurners = 0
var uazLocksmiths = 0
for worker in uazPlant.workers {
    if worker.speciality == "Токарь" {
       uazTurners += 1
    } else if worker.speciality == "Слесарь" {
        uazLocksmiths += 1
    }
}
print("Количество токарей на заводе УАЗ равно \(uazTurners) человек. \nКоличество слесарей на заводе УАЗ равно \(uazLocksmiths) человек.")
var kamazTurners = 0
var kamazLocksmiths = 0
for worker in kamazPlant.workers {
    if worker.speciality == "Токарь" {
       kamazTurners += 1
    } else if worker.speciality == "Слесарь" {
        kamazLocksmiths += 1
    }
}
print("Количество токарей на заводе КАМАЗ равно \(kamazTurners) человек. \nКоличество слесарей на заводе КАМАЗ равно \(kamazLocksmiths) человек.")
func workersCount(plant: Plant) {
    var countOfTurners = 0
    var countOfLocksmiths = 0
    for worker in plant.workers {
        if worker.speciality == "Токарь" {
           countOfTurners += 1
        } else if worker.speciality == "Слесарь" {
            countOfLocksmiths += 1
        }
    }
    print("Количество токарей на заводе \(plant.title) равно \(countOfTurners) человек. \nКоличество слесарей на заводе \(plant.title) равно \(countOfLocksmiths) человек.")
}
workersCount(plant: kamazPlant)
workersCount(plant: uazPlant)

//2. Определите структуру для представления записи информации о сданных студентом экзаменах (фамилия студента, число экзаменов, массив полученных оценок). Определите метод, который определяет, полагается ли студенту обычная стипендия (если все оценки 4 и 5) или повышенная (если средний балл выше 4.5) или максимальная (если студент - отличник, все оценки «5») или же он вообще не должен получать стипендии (имеются тройки). Используя спроектированный тип, напишите функцию или класс для обработки массива структур. В результате обработки требуется вычислить характеристику качественной успеваемости студентов, то есть(отношение числа студентов, сдавших экзамены на 4 и 5, к общему числу студентов, в %.
struct AcademicPerfomance {
    var studentSurname: String
    var examsCount: Int
    var grades: [Int]
    func stipend() {
        guard examsCount == grades.count else {
        return print("Студент по фамилии \(studentSurname) сдал не все экзамены для получения стипендии.")
        }
            var maxMarks = 0
            var sumOfMark = 0
            var lowMarks = 0
        for grade in grades {
            sumOfMark += grade
            if grade == 5 {
            maxMarks += 1
            } else if grade < 4 {
            lowMarks += 1
            }
        }
        if maxMarks < examsCount && lowMarks < 1 {
               print("Cтуденту по фамилии \(studentSurname) положена обычная стипендия")
            } else if Double(sumOfMark / examsCount) > 4.5 && Double(sumOfMark / examsCount) < 5 {
                print("Студенту по фамилии \(studentSurname) положена повышенная стипендия")
            } else if maxMarks == examsCount {
              print("Студенту по фамилии \(studentSurname) положена максимальная стипендия")
            } else {
                print("Успеваемость студента по фамилии \(studentSurname) недостаточна для получения стипендии")
            }
    }
}
        
func studentsPerf(students: [AcademicPerfomance]){
    for student in students {
        student.stipend()
    }
}
let petrov = AcademicPerfomance(studentSurname: "Петров", examsCount: 5, grades: [5, 5, 4, 3, 5])
let maksimova = AcademicPerfomance(studentSurname: "Максимова", examsCount: 3, grades: [5, 4, 5])
let magamedov = AcademicPerfomance(studentSurname: "Магамедов", examsCount: 4, grades: [5, 4, 5, 3])
let ivanov = AcademicPerfomance(studentSurname: "Иванов", examsCount: 4, grades: [4, 4, 5, 5])
let paramonova = AcademicPerfomance(studentSurname: "Парамонова", examsCount: 5, grades: [5, 5, 5, 5, 5])
let mamedov = AcademicPerfomance(studentSurname: "Мамедов", examsCount: 5, grades: [4, 5])
//maksimova.stipend()
//magamedov.stipend()
//mamedov.stipend()
//paramonova.stipend()
studentsPerf(students: [mamedov, magamedov, paramonova, ivanov, maksimova, petrov])

/*
3. Описать структуру с именем Note, содержащую следующие поля:
• name — фамилия, имя;
• phone — номер телефона;
• birthDay — день рождения (кортеж из трех чисел).
Написать программу, выполняющую следующие действия:
Создайте класс ContactBook, добавьте ему свойство contacts (массив типа Note) и заполните его 8-ю элементами
Напишите метод, выводящий на экран информацию о человеке, номер телефона которого передано в качестве параметра
Напишите метод, выводящий на экран информацию о людях, чьи дни рождения приходятся на месяц, значение которого передано в качестве параметра
*/

struct Note {
    let name: String
    var phone: Int
    let bithDay: (Int, Int, Int)
}

class ContactBook {
    var contacts: [Note]
    init(contacts: [Note]) {
        self.contacts = contacts
    }
    func infoByTel(tel: Int) {
        for contact in contacts {
            if tel == contact.phone {
                print("По данному номеру телефона найден контакт: \nИмя контакта: \(contact.name) \nДата дня рождения: \(contact.bithDay.0).0\(contact.bithDay.1).\(contact.bithDay.2)")
            }
        }
    }
    func birthDays(month: Int) {
        for contact in contacts {
            if month == contact.bithDay.1 {
                print("Дата рождения контакта с именем \(contact.name) номер телефона: \(contact.phone) приходится на заданный месяц (номер месяца \(month))")
            }
        }
    }
}
let vasya = Note(name: "Вася Петров", phone: 9153335689, bithDay: (24, 5, 1990))
let sveta = Note(name: "Светлана Измайлова", phone: 9058889457, bithDay: (10, 1, 1987))
let oleg = Note(name: "Олег Константинов", phone: 9034418832, bithDay: (15, 8, 1967))
let magamed = Note(name: "Магамед Абдулшарипов", phone: 9017777700, bithDay: (9, 7, 1996))
let lena = Note(name: "Елена Павлюченко", phone: 9058858585, bithDay: (6, 3, 1990))
let masha = Note(name: "Мария Кузнецова", phone: 9037654321, bithDay: (8, 12, 1991))
let pavel = Note(name: "Павел Дудин", phone: 9057783145, bithDay: (10, 10, 1990))
let sasha = Note(name: "Александр Александров", phone: 9067783451, bithDay: (14, 7, 1994))
let myContactBook = ContactBook(contacts: [vasya, sveta, oleg, magamed, lena, masha, pavel, sasha])
myContactBook.infoByTel(tel: 9067783451)
myContactBook.birthDays(month: 7)
